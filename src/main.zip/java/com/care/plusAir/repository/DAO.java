package com.care.plusAir.repository;

import org.springframework.stereotype.Repository;

@Repository
public class DAO {

}
